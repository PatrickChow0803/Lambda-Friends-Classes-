package com.patrickchow.friends;

import java.util.ArrayList;

public class ContactsManager {

    private ArrayList<Contact> contacts = new ArrayList<Contact>();

    public void createContact(String name, String phoneNumber){
        Contact contact = new Contact(name, phoneNumber);
        contacts.add(contact);
    }

    public Contact getContact(int index){
        return contacts.get(index);
    }

}
