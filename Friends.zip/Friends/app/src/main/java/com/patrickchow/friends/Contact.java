package com.patrickchow.friends;

public class Contact {

    private String name, phoneNumber;

    public Contact(String name, String phoneNumber){
        this.name = name;
        this.phoneNumber = phoneNumber;
    }

    public Contact(){
        this.name = "No Name Entered";
        this.phoneNumber = "No Number Entered";
    }

    public String getName(){
        return name;
    }

    public String getNumber(){
        return phoneNumber;
    }
}
