package com.patrickchow.friends;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText friends, number;
    Button   createContact;
    LinearLayout phoneLayout;

    //Used to keep track of indexes for ContactsManager
    int indexCounter = -1;

    //Take in a string and return a TextView version of it.
    public TextView createNewTextView(String text) {
        //Commented out code is for setting parameters for LinearLayout. Since I already did it in xml, it's not necessary. Just keeping it as reference.
        //final LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        final TextView textView = new TextView(this);
        //textView.setLayoutParams(lparams);
        textView.setText("Contact: " + text);
        return textView;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        friends = findViewById(R.id.friendsEditID);
        number = findViewById(R.id.numberEditID);
        createContact = findViewById(R.id.createBtnID);
        phoneLayout = findViewById(R.id.LinearLayoutID);
        final ContactsManager contactsManager = new ContactsManager();

        //Button that calls createContact and adds the contact to the view
        createContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                indexCounter++;
                String friendsName = friends.getText().toString();
                String friendsNumber = number.getText().toString();

                //Add the Name and the Number to the ArrayList
                contactsManager.createContact(friendsName,friendsNumber);

                //Create a contact to be able to reference the ArrayList.
                Contact contact = new Contact();
                contact = contactsManager.getContact(indexCounter);

                //Display the contacts Name and Phone Number.
                phoneLayout.addView(createNewTextView(contact.getName() + " " + contact.getNumber()));
            }
        });
    }
}
